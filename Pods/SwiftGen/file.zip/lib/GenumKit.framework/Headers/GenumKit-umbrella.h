#import <Cocoa/Cocoa.h>


FOUNDATION_EXPORT double GenumKitVersionNumber;
FOUNDATION_EXPORT const unsigned char GenumKitVersionString[];

